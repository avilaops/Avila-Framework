import os
import yaml
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt

console = Console()
BASE_DIR = Path(__file__).resolve().parents[1]
AGENTS_DIR = BASE_DIR / "agents"
LOGS_DIR = BASE_DIR / "logs"
CONFIG_PATH = BASE_DIR / "core" / "config.yaml"


def load_config():
    if CONFIG_PATH.exists():
        return yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
    console.print("[red]Arquivo de configuração não encontrado.[/red]")
    return None


def list_agents():
    agents = []
    for agent_dir in AGENTS_DIR.iterdir():
        if agent_dir.is_dir():
            config_file = agent_dir / "config.yaml"
            if config_file.exists():
                data = yaml.safe_load(config_file.read_text(encoding="utf-8"))
                agents.append({
                    "name": data.get("agent_name", agent_dir.name),
                    "area": data.get("area", "Desconhecida"),
                    "significado": data.get("significado", ""),
                    "path": str(agent_dir)
                })
    return agents


def show_agents(agents):
    table = Table(title="Agentes Ativos no On", show_lines=True)
    table.add_column("Nome", style="bold cyan")
    table.add_column("Área")
    table.add_column("Significado")

    for a in agents:
        table.add_row(a["name"], a["area"], a["significado"])
    console.print(table)


def open_agent(agent):
    console.rule(f"[bold green]{agent['name']} ativo")
    console.print(f"[cyan]Área:[/cyan] {agent['area']}")
    console.print(f"[cyan]Função:[/cyan] {agent['significado']}")
    console.print(f"[cyan]Diretório:[/cyan] {agent['path']}")

    LOGS_DIR.mkdir(exist_ok=True)
    log_path = LOGS_DIR / f"{agent['name'].lower()}_session.log"
    with open(log_path, "a", encoding="utf-8") as log:
        log.write(f"[Sessão iniciada com {agent['name']}]\n")
    console.print(f"\n[green]Log criado em:[/green] {log_path}\n")


def main():
    console.rule("[bold blue]ON CORE - ÁVILA OPS")
    config = load_config()
    if not config:
        return

    agents = list_agents()
    show_agents(agents)

    while True:
        console.print("\n[bold yellow]Menu:[/bold yellow]")
        console.print("1. Ativar agente")
        console.print("2. Mostrar configuração central")
        console.print("3. Abrir pasta de logs")
        console.print("4. Sair")

        choice = Prompt.ask("\nEscolha uma opção", choices=["1", "2", "3", "4"], default="4")

        if choice == "1":
            names = [a["name"].lower() for a in agents]
            name = Prompt.ask("Qual agente deseja ativar?", choices=names)
            agent = next(a for a in agents if a["name"].lower() == name)
            open_agent(agent)

        elif choice == "2":
            console.rule("Configuração Central")
            console.print_yaml(yaml.dump(config, allow_unicode=True, sort_keys=False))

        elif choice == "3":
            os.startfile(LOGS_DIR)

        elif choice == "4":
            console.print("[bold red]Encerrando On Core...[/bold red]")
            break


if __name__ == "__main__":
    main()
# AvilaOps/On/core/on_core.py