import logging
from on.core.on_storage import log as db_log

logger = logging.getLogger("on.core")
logger.setLevel(logging.INFO)

handler = logging.StreamHandler()
formatter = logging.Formatter(
    fmt="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S"
)
handler.setFormatter(formatter)
logger.addHandler(handler)

class AgentLogger:
    def __init__(self, agent_name: str):
        self.agent = agent_name

    def log(self, text: str):
        msg = f"[{self.agent}] {text}"
        logger.info(msg)
        db_log(self.agent, text)
