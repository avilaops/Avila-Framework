from datetime import datetime
from on.core.on_storage import update_heartbeat

def heartbeat(agent_name: str):
    update_heartbeat(agent_name, datetime.utcnow().isoformat())
